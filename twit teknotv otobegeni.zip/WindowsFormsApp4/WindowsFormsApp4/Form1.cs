﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        // Task.Delay(2000);

        //|| veya , &&ve
        //Beğenmeye başla butonu
        private void button3_Click(object sender, EventArgs e)
        {
            sayac = 0;
            
            if ( // combobox1'de farklı değer girilemesin
                (comboBox1.Text=="3"||
                comboBox1.Text == "4" ||
                comboBox1.Text == "5" ||
                comboBox1.Text == "6" ||
                comboBox1.Text == "7" ||
                comboBox1.Text == "8" ||
                comboBox1.Text == "9" ||
                comboBox1.Text == "10" ||
                comboBox1.Text == "15")
                && // combobox2'de farklı değer girilemesin
                (comboBox2.Text == "10" ||
                comboBox2.Text == "20" ||
                comboBox2.Text == "30" ||
                comboBox2.Text == "40" ||
                comboBox2.Text == "50" ||
                comboBox2.Text == "60" ||
                comboBox2.Text == "70" ||
                comboBox2.Text == "80" ||
                comboBox2.Text == "90" ||
                comboBox2.Text == "100")
                )
            { //belirlenen değerler girildiyse timer çalışsın
                timer1.Start();
            }

            else
            { //Farklı değer girilmeye çalışmalarını engelle
                MessageBox.Show("Seçiniz");
            }


        }

        //Beğenmeyi durdur butonu
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        //Programı kapat butonu
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Yeniden başlat butonu
        private void button4_Click(object sender, EventArgs e)
        {
            Application.Restart();
            MessageBox.Show("Program yeniden başlatıldı");
        }






        int sayac = 0;
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            sayac++;
            lblSaniye.Text = sayac.ToString();

            Thread.Sleep(150);
            SendKeys.Send("j");
            Thread.Sleep(150);
            SendKeys.Send("l");
            Thread.Sleep(25);

            if (sayac.ToString() == comboBox2.Text)
            {
                timer1.Stop();
                sayac = 0;
                MessageBox.Show("Tamamlandı","!",MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "3")
            {
                timer1.Interval = 3000;
            }

            if (comboBox1.Text == "4")
            {
                timer1.Interval = 4000;
            }

            if (comboBox1.Text == "5")
            {
                timer1.Interval = 5000;
            }

            if (comboBox1.Text == "6")
            {
                timer1.Interval = 6000;
            }

            if (comboBox1.Text == "7")
            {
                timer1.Interval = 7000;
            }

            if (comboBox1.Text == "8")
            {
                timer1.Interval = 8000;
            }

            if (comboBox1.Text == "9")
            {
                timer1.Interval = 9000;
            }

            if (comboBox1.Text == "10")
            {
                timer1.Interval = 10000;
            }

            if (comboBox1.Text == "15")
            {
                timer1.Interval = 15000;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblSaniye.Text = "0";
            timer1.Interval = 3000;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            //Tıkladığımızda mouse tuşu aşağı doğru hareket edince gerçekleşir.
            {
                dragging = true;
                dragCursorPoint = Cursor.Position;
                dragFormPoint = this.Location;
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            //Mouse hareket ederse gerçekleşecek ifadeler. Biz basılı iken hareket etmesi için dragging tanımladık.
            {
                if (dragging)
                {
                    Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                    this.Location = Point.Add(dragFormPoint, new Size(dif));
                }
            }
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            //Mouse tuşu yukarı kalktığında gerçekleşecek ifademiz. 
            {
                dragging = false;
            }
        }

        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
